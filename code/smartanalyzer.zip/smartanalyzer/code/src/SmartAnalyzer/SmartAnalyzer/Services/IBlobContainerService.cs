﻿using SmartAnalyzer.Models;

namespace SmartAnalyzer.Services
{
    public interface IBlobContainerService
    {
        Task<SearchStorageRequest> GetAllBlobsByContainer(SearchRequest searchRequest);
    }
}
