﻿using Microsoft.AspNetCore.Mvc;
using SmartAnalyzer.Models;
using SmartAnalyzer.Services;
using System.Diagnostics;

namespace SmartAnalyzer.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IBlobContainerService _blobContainerService;
        public HomeController(ILogger<HomeController> logger, IBlobContainerService blobContainerService)
        {
            _logger = logger;
            _blobContainerService = blobContainerService;
        }
        
        public async Task<IActionResult> Index(string context, string category, string noOfMatches, string threshold, string inputPath)
        {
            if (context != null)
            {
                SearchRequest searchRequest = new SearchRequest() { context = context , category = category, noOfMatches = int.Parse(noOfMatches) , threshold = decimal.Parse(threshold),inputFilePath = inputPath };
                SearchStorageRequest searchStorageRequest = new SearchStorageRequest();
                searchStorageRequest = await _blobContainerService.GetAllBlobsByContainer(searchRequest);
                if (searchStorageRequest.FileInfoDetail.Count > 0)
                {

                }
            }
            return View();
        }      
    }
}
