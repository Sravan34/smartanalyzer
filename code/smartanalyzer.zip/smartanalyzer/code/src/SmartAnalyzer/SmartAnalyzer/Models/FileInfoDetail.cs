﻿namespace SmartAnalyzer.Models
{
    public class FileInfoDetail
    {
        public string id { get; set; }
        public string path { get; set; }
    }
}